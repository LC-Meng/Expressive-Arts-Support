Qualitative coding and service materials

qualitative_codebook contains CSV exports of the complete cell grids of the
three supplied workbook sheets: open coding, axial coding and selective coding.
Blank cells preserve the hierarchy as stored. The original coding content and
stage-specific terminology have not been changed during packaging. These files
are not the nine-code ENA codebook, which is in 03_ENA_analysis/data.
Relevant locations: Section 4.4, Table 4, Figure 2 and Appendix E.

programme_documents contains the original research and recruitment plans as
plain text. These are source plans, not confirmation that all procedures were
implemented exactly as written. Relevant locations: Sections 3.1-3.2 and
Appendices B-C.

context_photographs contains the supplied activity, material and artwork
photographs. Existing obscuring of faces is retained; no photograph was redrawn,
retouched or used to generate a new observation record. These images provide
context for Section 3.2 and Appendix C. They do not constitute independently
coded visual data, and no participant identity or session timing has been
inferred from filenames. The supplied folder label "observation records" has
not been used to misdescribe photographs as written field notes.
Identifying EXIF/XMP/text metadata is removed from review copies without changing
image pixels. Non-identifying source date/camera fields are retained separately
in photograph_source_metadata.csv. A file's camera date is not taken as proof of
its association with a particular study session. Originals remain local.

current_manuscript_figures contains the exact image objects extracted from the
current manuscript: Figure 2 (three-tier system model), Figure 3 (theory-process-
experience foundation), Figure 4 (responsive service cycle) and Figure 5
(service blueprint). Figure 1 belongs to the ENA model output instead.
The older editable PowerPoint has different terminology and is retained locally
as a source draft; it is not an additional set of current manuscript figures.

The native NVivo project files and the original XLSX workbook are preserved
locally. The current package supplies the text/cell exports for review without
requiring NVivo or exposing author profile metadata. NVivo reference-level
exports used for secondary ENA mapping are stored once in 03_ENA_analysis/data.
