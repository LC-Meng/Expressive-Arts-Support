Supplementary ENA analysis

This is the single current ENA data/code/output set. Earlier results are not
included. The original qualitative analysis remains in folder 02. ENA is a
source-linked secondary mapping of interview passages, not a rerun of the
grounded-theory categories and not an independent data source.

Input and evidence
  data/01_NVivo_references.csv: 106 exported reference records, including the
    duplicate reference retained for traceability.
  data/source_reference_pages: original-format HTML reference passages. Speaker
    surname labels, where present, use participant codes in the review copies.
  data/02_Reference_code_mapping.csv: reference-level nine-code mapping,
    supporting text, evidence type and rationale.
  data/04_Code_decisions.csv: 954 reference-by-code decisions (106 x 9).
  data/05_Final_stanzas_traceable.csv: 105 ordered retained segments after
    duplicate removal, linked to their reference IDs.
  data/06_ENA_input.csv: the exact binary calculation input. There are 32 units,
    105 segments, nine binary code columns and 40 all-zero coded segments.
  data/08_Operational_codebook.csv: operational definitions and exclusions.
  data/09_Source_context.csv: source paragraph pointers and context notes.
    Full transcripts are in ../01_Interview_and_questionnaire_data/transcripts.
  data/11_Figure_label_map.csv: display terminology and earlier label mapping.
    Earlier labels are provenance information, not the current figure labels.
  data/analysis_protocol.txt: analytical scope and mapping rules.

Model and code
  Participant is the unit; each participant's interview is the conversation;
  Cohort is the grouping variable. EndPoint modelling uses binary weighting and
  a moving window of the current retained segment and two preceding retained
  segments. Retained segments need not be consecutive original utterances.
  Zero-code segments remain in the sequence. Network vectors are L2-normalised
  before means rotation. The nine code columns are HV, MT, SG, AV, CA, PR, VS,
  EB and IR; see the operational codebook, rather than inferring their meaning
  from an older label or from the original qualitative categories.

  code/original_analysis.R is the fitting core called by code/run_review.R.
  code/run_review.R runs all four variants, independent numerical checks,
    rotated-axis rank-sum summaries, and 4,999 label permutations per variant.
  code/plot_submission.R draws the full-sample and non-zero-network figures
    using calculated node coordinates and connection weights.

Results
  results/01_all32_same_settings: all 32 participants (16/16), including nine
    zero co-occurrence networks. This is the full-sample model.
  results/02_nonzero_networks: the 23 non-zero networks (12/11). Figure_1_ENA.pdf
    and Figure_1_ENA.png in this directory correspond to manuscript Figure 1.
  results/03_EB_boundary_R048_zero: full-sample sensitivity analysis in which
    EB is set to 0 for the segment linked to reference R048.
  results/04_nonzero_EB_boundary: the corresponding 23-unit sensitivity model.
  statistics_comparison.csv and permutation_comparison.csv combine the four
    variants; individual statistics.csv and permutation_test.csv files retain
    each run's results.

  Each model includes its actual input, fitted R object, participant connection
  counts, normalised edge vectors, centred projection vectors, rotation matrix,
  node and participant coordinates, cohort mean/difference weights, projection-
  centroid correlations, permutation distances, settings and session information.
  analysis_input.csv is the input to the fitting core; input_used.csv additionally
  records the conversation identifier. They are intentionally not identical.

Interpretation
  The MR1 axis uses cohort labels for rotation. Its nominal Wilcoxon p-values and
  rank-biserial correlations describe the rotated sample and do not independently
  establish cohort separation. Permutation p-values are .3656 (all 32), .3766
  (23 non-zero), .4624 (all 32, EB boundary) and .4686 (23 non-zero, EB boundary).
  These results do not establish a clear group difference. The cohort comparison
  is not a causal or within-person estimate of an activity replacement effect.

Execution from the package root
  Rscript 03_ENA_analysis/code/run_review.R
  Rscript 03_ENA_analysis/code/plot_submission.R
Numerical environment: R 4.6.1; rENA 0.3.1; jsonlite 2.0.0. The plotting script
uses macOS Quartz and Times New Roman. Relative paths were adjusted for this
layout; the code definitions, model settings and reported results were not changed.
