# Draw only computed rENA positions and weights; captions remain in the manuscript.
args <- commandArgs(trailingOnly=FALSE)
script <- sub('^--file=', '', args[grepl('^--file=', args)])
root <- dirname(normalizePath(script))
red <- '#B72F3A'
blue <- '#087EA4'
quartzFonts(TNR=quartzFont(c('TimesNewRomanPSMT','TimesNewRomanPS-BoldMT',
                           'TimesNewRomanPS-ItalicMT','TimesNewRomanPS-BoldItalicMT')))

plot_variant <- function(variant) {
  out <- file.path(dirname(root),'results',variant)
  nodes <- read.csv(file.path(out,'nodes.csv'))
  edges <- read.csv(file.path(out,'edge_weights.csv'))
  pts <- read.csv(file.path(out,'participant_locations.csv'))
  stats <- read.csv(file.path(out,'statistics.csv'))
  support <- read.csv(file.path(out,'participant_network_support.csv'))
  pairs <- strsplit(edges$edge,' & ',fixed=TRUE)
  max_mean <- max(edges$Cohort1_mean,edges$Cohort2_mean)
  max_diff <- max(abs(edges$Cohort2_minus_Cohort1))
  max_freq <- max(nodes$freq_c1,nodes$freq_c2)
  lim <- function(x, pad=0.20) {r<-range(x);r+c(-1,1)*max(diff(r)*pad,0.05)}
  xlab <- sprintf('MR1 (%.2f%%)',stats$VariancePercent[1])
  ylab <- sprintf('SVD2 (%.2f%%)',stats$VariancePercent[2])
  network <- function(value,heading,mode) {
    plot(nodes$x,nodes$y,type='n',xlim=lim(nodes$x,0.27),ylim=lim(nodes$y,0.24),
         xlab=xlab,ylab=ylab,main=heading,asp=1,axes=FALSE,cex.main=1.0)
    axis(1,cex.axis=0.82);axis(2,cex.axis=0.82,las=1)
    abline(h=0,v=0,col='grey85',lty=3)
    scale <- if(mode==3)max_diff else max_mean
    for(i in order(abs(value))) {
      if(value[i]==0)next
      a <- nodes[match(pairs[[i]][1],nodes$key),]
      b <- nodes[match(pairs[[i]][2],nodes$key),]
      strength <- sqrt(abs(value[i])/scale)
      colour <- if(mode==3) {if(value[i]>0)blue else red} else {if(mode==1)red else blue}
      segments(a$x,a$y,b$x,b$y,lwd=0.2+5*strength,
               col=adjustcolor(colour,alpha.f=0.12+0.88*strength^1.5))
    }
    freq <- if(mode==1)nodes$freq_c1 else if(mode==2)nodes$freq_c2 else nodes$freq_c1+nodes$freq_c2
    divisor <- if(mode==3)max(nodes$freq_c1+nodes$freq_c2) else max_freq
    points(nodes$x,nodes$y,pch=21,bg=ifelse(freq>0,'grey20','white'),
           col='grey25',cex=0.65+1.4*sqrt(freq/divisor))
    pos <- c(HV=2,MT=4,SG=2,AV=4,CA=2,PR=2,VS=4,EB=3,IR=1)
    lx<-nodes$x;ly<-nodes$y
    ly[nodes$key=='EB']<-ly[nodes$key=='EB']+0.08
    text(lx,ly,nodes$key,pos=pos[nodes$key],offset=0.75,cex=0.87,font=2)
  }
  draw <- function() {
    par(mfrow=c(2,2),mar=c(3.0,3.1,2.1,0.6),oma=c(0,0,0,0),
        mgp=c(1.8,0.5,0),family='TNR')
    network(edges$Cohort1_mean,sprintf('(a) Cohort 1: n = %d',stats$N1[1]),1)
    network(edges$Cohort2_mean,sprintf('(b) Cohort 2: n = %d',stats$N2[1]),2)
    network(edges$Cohort2_minus_Cohort1,'(c) Difference: Cohort 2 minus Cohort 1',3)
    legend('topleft',c('Stronger in Cohort 1','Stronger in Cohort 2'),
           col=c(red,blue),lwd=2,bty='n',cex=0.67)
    zero<-support$Participant[!support$HasNetwork]
    colours<-ifelse(pts$cohort=='Cohort 1',red,blue)
    plot(pts$x,pts$y,pch=ifelse(pts$id %in% zero,1,16),col=adjustcolor(colours,0.75),
         xlim=lim(pts$x),ylim=lim(pts$y),xlab=xlab,ylab=ylab,
         main='(d) Individual network locations',cex=0.85,cex.axis=0.82,cex.main=1.0)
    abline(h=0,v=0,col='grey85',lty=3)
    for(group in c('Cohort 1','Cohort 2')) {
      p<-pts[pts$cohort==group,]
      points(mean(p$x),mean(p$y),pch=22,bg=if(group=='Cohort 1')red else blue,col='white',cex=1.8)
    }
    legend('topleft',c('Cohort 1','Cohort 2','Group mean'),pch=c(16,16,22),
           col=c(red,blue,'grey25'),pt.bg=c(NA,NA,'grey25'),bty='n',cex=0.7)
  }
  quartz(type='pdf',file=file.path(out,'Figure_1_ENA.pdf'),width=12,height=9,
         family='TNR',pointsize=18,title='')
  draw();dev.off()
  png(file.path(out,'Figure_1_ENA.png'),width=3600,height=2700,res=300,
      pointsize=18,type='quartz')
  draw();dev.off()
}
plot_variant('01_all32_same_settings')
plot_variant('02_nonzero_networks')
cat('R-generated figures saved without overall titles or abbreviation notes.\n')
