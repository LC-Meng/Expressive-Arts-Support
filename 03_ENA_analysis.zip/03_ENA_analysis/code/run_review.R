# All-reference ENA reassessment, 18 October 2026. Model settings are unchanged.
args <- commandArgs(trailingOnly=FALSE)
script <- sub("^--file=", "", args[grepl("^--file=",args)])
root <- dirname(normalizePath(script))
data_dir <- file.path(dirname(root), "data")
out_root <- file.path(dirname(root), "results")
dir.create(out_root, showWarnings=FALSE)
stopifnot(requireNamespace("rENA", quietly=TRUE), requireNamespace("jsonlite", quietly=TRUE))
codes <- c("HV","MT","SG","AV","CA","PR","VS","EB","IR")
input <- read.csv(file.path(data_dir,"06_ENA_input.csv"), check.names=FALSE)
trace <- read.csv(file.path(data_dir,"05_Final_stanzas_traceable.csv"), check.names=FALSE)
stopifnot(nrow(input)==105, length(unique(input$Participant))==32)

fit <- function(dat, variant) {
  out <- file.path(out_root,variant)
  dir.create(out,showWarnings=FALSE)
  input_path <- file.path(out,"analysis_input.csv")
  write.csv(dat,input_path,row.names=FALSE)
  source <- readLines(file.path(root,"original_analysis.R"),encoding="UTF-8")
  source[grepl("^input_file <-",source)] <- paste0("input_file <- ",deparse(input_path))
  source[grepl("^out_dir <-",source)] <- paste0("out_dir <- ",deparse(out))
  env <- new.env(parent=globalenv())
  eval(parse(text=source),envir=env)
  fig <- jsonlite::fromJSON(file.path(out,"figure_data.json"),simplifyVector=FALSE)
  fig$source <- paste("Source-linked semantic reassessment, 18 October 2026:",variant)
  jsonlite::write_json(fig,file.path(out,"figure_data.json"),auto_unbox=TRUE,pretty=TRUE,digits=12)
  model <- env$ena_set
  p <- as.data.frame(model$points)
  counts <- as.data.frame(model$connection.counts)
  weights <- as.data.frame(model$line.weights)
  edge_cols <- grep(" & ",names(weights),value=TRUE,fixed=TRUE)
  stopifnot(length(edge_cols)==36)
  raw <- as.matrix(counts[,edge_cols])
  norm <- sqrt(rowSums(raw^2))
  expected <- raw
  expected[norm>0,] <- raw[norm>0,,drop=FALSE]/norm[norm>0]
  stopifnot(max(abs(expected-as.matrix(weights[,edge_cols])))<1e-10)
  support <- data.frame(Participant=counts$Participant,Cohort=counts$Cohort,
    ConnectionSum=rowSums(raw),NonZeroEdges=rowSums(raw>0),HasNetwork=norm>0)
  write.csv(support,file.path(out,"participant_network_support.csv"),row.names=FALSE)
  write.csv(counts,file.path(out,"unit_connection_counts.csv"),row.names=FALSE)
  write.csv(weights,file.path(out,"unit_normalised_edge_weights.csv"),row.names=FALSE)
  write.csv(as.data.frame(model$rotation.matrix),file.path(out,"rotation_matrix.csv"),row.names=FALSE)
  write.csv(as.data.frame(model$model$points.for.projection),file.path(out,"centred_edge_vectors.csv"),row.names=FALSE)
  correlations <- rENA::ena.correlations(model)
  correlations[] <- lapply(correlations, unlist)
  write.csv(correlations, file.path(out, "projection_centroid_correlations.csv"), row.names=FALSE)
  n1 <- sum(p$Cohort=="Cohort 1")
  n2 <- sum(p$Cohort=="Cohort 2")
  stats <- do.call(rbind,lapply(seq_along(c("MR1","SVD2")),function(i) {
    dim <- c("MR1","SVD2")[i]
    test <- model$tests$wilcox.test[[paste0("test.dim",i)]]
    w <- as.numeric(test$statistic)
    ranks <- rank(p[[dim]],ties.method="average")
    independent_w <- sum(ranks[p$Cohort=="Cohort 1"])-n1*(n1+1)/2
    stopifnot(abs(w-independent_w)<1e-9)
    data.frame(Variant=variant,Dimension=dim,N1=n1,N2=n2,W=w,NominalP=test$p.value,
      RankBiserialR=2*w/(n1*n2)-1,VariancePercent=100*model$model$variance[dim],
      Method=test$method,Alternative=test$alternative,
      ZeroNetworkUnits=sum(!support$HasNetwork))
  }))
  write.csv(stats,file.path(out,"statistics.csv"),row.names=FALSE)
  writeLines(capture.output(model$tests$wilcox.test),file.path(out,"wilcoxon_tests.txt"))
  # Each permutation recomputes the group-mean difference; its length is invariant
  # to the subsequently chosen mean-rotation direction.
  projection <- as.data.frame(model$model$points.for.projection)
  x <- as.matrix(projection[,edge_cols])
  group <- projection$Cohort=="Cohort 1"
  distance <- function(g) sqrt(sum((colMeans(x[g,,drop=FALSE])-colMeans(x[!g,,drop=FALSE]))^2))
  observed <- distance(group)
  axis_gap <- abs(mean(p$MR1[p$Cohort=="Cohort 1"])-mean(p$MR1[p$Cohort=="Cohort 2"]))
  stopifnot(abs(axis_gap-observed)<1e-9)
  set.seed(20261016)
  b <- 4999L
  perm <- replicate(b,distance(sample(group)))
  perm_p <- (1+sum(perm>=observed-1e-12))/(b+1)
  permutation <- data.frame(Variant=variant,ObservedMeanDistance=observed,
    Permutations=b,Seed=20261016,Exceedances=sum(perm>=observed-1e-12),PermutationP=perm_p,
    MonteCarloSE=sqrt(perm_p*(1-perm_p)/(b+1)))
  write.csv(permutation,file.path(out,"permutation_test.csv"),row.names=FALSE)
  write.csv(data.frame(Permutation=seq_len(b),MeanDistance=perm),file.path(out,"permutation_distances.csv"),row.names=FALSE)
  writeLines(capture.output(sessionInfo()),file.path(out,"sessionInfo.txt"))
  writeLines(capture.output(model$`_function.params`),file.path(out,"model_parameters.txt"))
  write.csv(data.frame(Check=c("L2 normalisation independently reproduced","W independently reproduced from ranks",
    "Mean-rotation separation equals mean-vector distance"),Result="PASS"),file.path(out,"numerical_checks.csv"),row.names=FALSE)
  print(stats)
  print(permutation)
  list(stats=stats,permutation=permutation,support=support,model=model)
}

primary <- fit(input,"01_all32_same_settings")
nonzero <- primary$support$Participant[primary$support$HasNetwork]
nonzero_fit <- fit(input[input$Participant %in% nonzero,],"02_nonzero_networks")
strict <- input
idx <- grepl("R048",trace$ReferenceIDs,fixed=TRUE)
stopifnot(sum(idx)==1, strict$EB[idx]==1)
strict$EB[idx] <- 0L
strict_fit <- fit(strict,"03_EB_boundary_R048_zero")
strict_nonzero <- strict_fit$support$Participant[strict_fit$support$HasNetwork]
strict_nonzero_fit <- fit(strict[strict$Participant %in% strict_nonzero,],"04_nonzero_EB_boundary")
all_stats <- rbind(primary$stats,nonzero_fit$stats,strict_fit$stats,strict_nonzero_fit$stats)
all_perm <- rbind(primary$permutation,nonzero_fit$permutation,strict_fit$permutation,strict_nonzero_fit$permutation)
write.csv(all_stats,file.path(out_root,"statistics_comparison.csv"),row.names=FALSE)
write.csv(all_perm,file.path(out_root,"permutation_comparison.csv"),row.names=FALSE)
cat("All four model runs and numerical checks completed.\n")
