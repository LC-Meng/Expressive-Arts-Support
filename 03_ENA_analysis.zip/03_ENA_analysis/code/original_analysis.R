# Fit rENA to source-linked binary codes. Qualitative categories are unchanged.

if (!requireNamespace("rENA", quietly = TRUE)) {
  stop("Package 'rENA' is not installed.")
}
if (!requireNamespace("jsonlite", quietly = TRUE)) {
  stop("Package 'jsonlite' is not installed.")
}

input_file <- "../data/06_ENA_input.csv"
out_dir <- "../results/01_all32_same_settings"
dir.create(out_dir, showWarnings = FALSE)

dat <- read.csv(input_file, stringsAsFactors = FALSE, check.names = FALSE, fileEncoding = "UTF-8-BOM")
code_cols <- c("HV", "MT", "SG", "AV", "CA", "PR", "VS", "EB", "IR")
dat[code_cols] <- lapply(dat[code_cols], as.integer)
dat$Conversation <- dat$Participant

ena_set <- rENA::ena(
  data = dat,
  units = c("Participant", "Cohort"),
  conversation = c("Conversation"),
  codes = code_cols,
  metadata = c("Cohort", "Participant", "Segment"),
  model = "EndPoint",
  weight.by = "binary",
  window = "MovingStanzaWindow",
  window.size.back = 3,
  groupVar = "Cohort",
  groups = c("Cohort 1", "Cohort 2"),
  runTest = TRUE,
  points = TRUE,
  mean = TRUE,
  network = TRUE,
  print.plots = FALSE
)

saveRDS(ena_set, file.path(out_dir, "ena_set.rds"))
write.csv(dat, file.path(out_dir, "input_used.csv"), row.names = FALSE, fileEncoding = "UTF-8")

code_labels <- data.frame(
  key = code_cols,
  cn = c("直接披露要求", "材料表达", "感官实践", "回避", "能力与自我评价顾虑", "隐私与被评价顾虑", "自愿连接与分享", "已体验的情绪缓解", "自我与身份反思"),
  en = c(
    "Direct disclosure demands",
    "Material expression",
    "Sensory practices",
    "Avoidance",
    "Competence/self-evaluation concerns",
    "Privacy/judgement concerns",
    "Voluntary connection/sharing",
    "Experienced emotional relief",
    "Self/identity reflection"
  ),
  stringsAsFactors = FALSE
)

node_pos <- as.data.frame(ena_set$rotation$nodes)
nodes <- merge(code_labels, node_pos[, c("code", "MR1", "SVD2")], by.x = "key", by.y = "code", all.x = TRUE, sort = FALSE)
for (code in code_cols) {
  nodes[nodes$key == code, "freq_c1"] <- sum(dat[dat$Cohort == "Cohort 1", code], na.rm = TRUE)
  nodes[nodes$key == code, "freq_c2"] <- sum(dat[dat$Cohort == "Cohort 2", code], na.rm = TRUE)
}
names(nodes)[names(nodes) == "MR1"] <- "x"
names(nodes)[names(nodes) == "SVD2"] <- "y"

edge_cols <- setdiff(names(ena_set$line.weights), c("ENA_UNIT", "Participant", "Cohort"))
line_weights <- as.data.frame(ena_set$line.weights)
mean_c1 <- colMeans(line_weights[line_weights$Cohort == "Cohort 1", edge_cols, drop = FALSE], na.rm = TRUE)
mean_c2 <- colMeans(line_weights[line_weights$Cohort == "Cohort 2", edge_cols, drop = FALSE], na.rm = TRUE)
pairs <- lapply(edge_cols, function(name) {
  parts <- strsplit(name, " & ", fixed = TRUE)[[1]]
  c(match(parts[1], code_cols) - 1, match(parts[2], code_cols) - 1)
})

points <- as.data.frame(ena_set$points[, c("Participant", "Cohort", "MR1", "SVD2")])
names(points) <- c("id", "cohort", "x", "y")
n1 <- sum(points$cohort == "Cohort 1")
n2 <- sum(points$cohort == "Cohort 2")
w1 <- as.numeric(ena_set$tests$wilcox.test$test.dim1$statistic)
w2 <- as.numeric(ena_set$tests$wilcox.test$test.dim2$statistic)

figure_data <- list(
  source = "rENA output from source-linked secondary ENA coding, 18 October 2026",
  codes = code_labels,
  nodes = nodes,
  pairs = pairs,
  participants = points,
  mean_c1 = as.numeric(mean_c1),
  mean_c2 = as.numeric(mean_c2),
  sub = as.numeric(mean_c2 - mean_c1),
  edge_names = edge_cols,
  varexp = as.numeric(ena_set$model$variance[c("MR1", "SVD2")]) * 100,
  stats = list(
    MR1 = list(
      W = w1,
      p = ena_set$tests$wilcox.test$test.dim1$p.value,
      rank_biserial_r = (2 * w1 / (n1 * n2)) - 1
    ),
    SVD2 = list(
      W = w2,
      p = ena_set$tests$wilcox.test$test.dim2$p.value,
      rank_biserial_r = (2 * w2 / (n1 * n2)) - 1
    )
  )
)

jsonlite::write_json(
  figure_data,
  file.path(out_dir, "figure_data.json"),
  pretty = TRUE,
  auto_unbox = TRUE,
  digits = 8
)
write.csv(nodes, file.path(out_dir, "nodes.csv"), row.names = FALSE, fileEncoding = "UTF-8")
write.csv(points, file.path(out_dir, "participant_locations.csv"), row.names = FALSE, fileEncoding = "UTF-8")
write.csv(
  data.frame(
    edge = edge_cols,
    Cohort1_mean = as.numeric(mean_c1),
    Cohort2_mean = as.numeric(mean_c2),
    Cohort2_minus_Cohort1 = as.numeric(mean_c2 - mean_c1)
  ),
  file.path(out_dir, "edge_weights.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

cat(sprintf(
  "W=%.1f, p=%.8f, rank-biserial r=%.8f\n",
  w1,
  ena_set$tests$wilcox.test$test.dim1$p.value,
  (2 * w1 / (n1 * n2)) - 1
))
