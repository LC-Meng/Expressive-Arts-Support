Interview and questionnaire data

transcripts: 32 full Chinese interview texts, one per participant. P000-based
paragraph numbering preserves the supplied Word document order. Participant
codes replace speaker surnames. See participant_cohort.csv for the two groups.
The original guide concerns pre-programme experiences and expectations; do not
infer a collection date or follow-up time for a transcript from its folder name.

instruments: the original interview guide and question list, in UTF-8 text.
These correspond to Section 3.3 and Appendix D.

questionnaires/preprogramme: original instrument, 32 complete individual
response texts and the platform aggregate report. Relevant to Table 1 and
Section 4.1. The original answers and response-option wording are retained.

questionnaires/followup: original follow-up instrument, 32 complete individual
response texts and the platform aggregate report. Relevant to Table 2, Section
4.2 and Appendix G. These are retrospective experience responses, not a
randomised or paired pre/post outcome test.

Instruments and individual response exports are preserved separately because
the wording/options in a supplied response export may differ from the supplied
instrument draft. A blank/omitted answer is not converted into a zero. Multi-
response answers retain the source separators and free-text details.

participant_cohort.csv
  Participant: pseudonymous file identifier, e.g. AF-01 or BM-01.
  Cohort: Cohort 1 for A-prefix records; Cohort 2 for B-prefix records.
  Transcript: relative path to the complete corresponding interview text.
The lookup follows the participant-coded source filenames, not surname matching.
No surname key, audio or personal contact information is included here.

FILE_INDEX.csv in the parent directory supplies the file-by-file manuscript map.
